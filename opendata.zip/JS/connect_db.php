<?php

$connection = mysqli_connect("localhost", "mysql", "mysql", "open_data");
mysqli_set_charset($connection, "utf8");

?>